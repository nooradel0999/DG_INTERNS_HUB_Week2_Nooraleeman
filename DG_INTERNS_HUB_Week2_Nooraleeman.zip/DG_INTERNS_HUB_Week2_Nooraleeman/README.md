# DG INTERNS HUB - AI/ML Internship | Week 2 Task
## Data Handling using NumPy & Pandas

**Intern:** Nooraleeman Adel Al-shawesh
**Date:** 12 October 2026  |  **Deadline:** 14 October 2026 (11:59 PM)

## Contents
| Folder / File | Description |
|---|---|
| `code/week2_task.py` | Complete runnable Python script (Tasks 1-4 + Bonus) |
| `data/employees.csv` | Dataset used (208 rows x 7 columns, with planted issues) |
| `screenshots/` | 7 uniform execution screenshots (Task 1 → Bonus) |
| `Week2_Report_Nooraleeman_Adel_AlShawesh.docx` | Full professional Word report |
| `Week2_Slides_Nooraleeman_Adel_AlShawesh.pptx` | Summary slide deck (10 slides) |

## How to Run
```bash
pip install pandas numpy
python code/week2_task.py
```
Make sure `employees.csv` is in a `data/` folder relative to the script
(or update `CSV_PATH` inside the script).

## Tasks Covered
1. **Task 1** - Load CSV, show head(5), tail(5), shape, columns.
2. **Task 2** - Check missing values, fill (mean/median), remove duplicates.
3. **Task 3** - Mean, median, mode, min/max, unique-value counts.
4. **Task 4** - NumPy arrays: addition, multiplication, reshaping.
5. **Bonus** - Filter Salary > 50,000 and show top 10 records.
