"""
============================================================
 DG INTERNS HUB - AI/ML Internship | Week 2 Task
 Topic : Data Handling using NumPy & Pandas
 Author: Nooraleeman Adel Al-shawesh
 Date  : 12 October 2026
============================================================
"""
import numpy as np
import pandas as pd

CSV_PATH = "data/employees.csv"

# ---------------------------------------------------------------
# TASK 1 : Dataset Loading & Understanding
# ---------------------------------------------------------------
df = pd.read_csv(CSV_PATH)

print("=" * 60)
print("TASK 1 - DATASET LOADING & UNDERSTANDING")
print("=" * 60)
print("\n[First 5 rows]")
print(df.head())
print("\n[Last 5 rows]")
print(df.tail())
print("\n[Dataset shape (rows, columns)]:", df.shape)
print("\n[Column names]:", list(df.columns))
print("\n[Data types]:")
print(df.dtypes)

# ---------------------------------------------------------------
# TASK 2 : Data Cleaning
# ---------------------------------------------------------------
print("\n" + "=" * 60)
print("TASK 2 - DATA CLEANING")
print("=" * 60)

print("\n[Missing values per column - BEFORE cleaning]")
print(df.isna().sum())

before_rows = len(df)
df = df.drop_duplicates()                      # remove duplicate rows
df["Age"] = df["Age"].fillna(df["Age"].median())               # fill with median
df["Salary"] = df["Salary"].fillna(df["Salary"].mean())        # fill with mean
df["Performance_Score"] = df["Performance_Score"].fillna(df["Performance_Score"].median())

print(f"\nRemoved {before_rows - len(df)} duplicate rows.")
print("\n[Missing values per column - AFTER cleaning]")
print(df.isna().sum())

# ---------------------------------------------------------------
# TASK 3 : Data Analysis (descriptive statistics)
# ---------------------------------------------------------------
print("\n" + "=" * 60)
print("TASK 3 - DATA ANALYSIS")
print("=" * 60)
num_cols = ["Age", "Salary", "Years_Experience", "Performance_Score"]
stats = df[num_cols].agg(["mean", "median", "min", "max"]).round(2)
print("\n[Mean / Median / Min / Max]")
print(stats)

print("\n[Mode]")
print(df[num_cols].mode().iloc[0])

print("\n[Count of unique values per column]")
print(df.nunique())

print("\n[Average salary]:", round(df["Salary"].mean(), 2))
print("[Most frequent department]:", df["Department"].mode()[0])

# ---------------------------------------------------------------
# TASK 4 : NumPy Practice
# ---------------------------------------------------------------
print("\n" + "=" * 60)
print("TASK 4 - NUMPY PRACTICE")
print("=" * 60)
a = np.array([1, 2, 3, 4, 5, 6])
b = np.array([10, 20, 30, 40, 50, 60])
print("\nArray a       :", a)
print("Array b       :", b)
print("Addition a+b  :", a + b)
print("Multiply a*b  :", a * b)
print("Reshape (2x3) :\n", a.reshape(2, 3))
print("Reshape (3x2) :\n", a.reshape(3, 2))

# ---------------------------------------------------------------
# BONUS TASK : Filtering the dataset
# ---------------------------------------------------------------
print("\n" + "=" * 60)
print("BONUS TASK - FILTERING")
print("=" * 60)
high_earners = df[df["Salary"] > 50000]
print(f"\nEmployees with Salary > 50,000 : {len(high_earners)} rows")
print(high_earners.head(10))

print("\n[Top 10 records sorted by Salary]")
print(df.sort_values("Salary", ascending=False).head(10))
